'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def linier_search(names, target_name):
    low = 0
    high = len(names) - 1

    while low <= high:
        mid = (low + high) // 2
        mid_name = names[mid]

        if mid_name < target_name:
            low = mid + 1
        elif mid_name > target_name:
            high = mid - 1
        else:
            return mid
    return -1

def example_case():
    
    names = ["yanto", "Alex", "udin", "ucup", "epul", "sumanto", "janggar", "praroro", "anies"]
    
    names.sort()
    print("Daftar nama karyawan setelah diurutkan:")
    for name in names:
        print(name)
    
    
    target_name = "epul"
    
    result = binary_search(names, target_name)
    
    if result != -1:
        print(f"Nama karyawan '{target_name}' ditemukan pada indeks {result}.")
    else:
        print(f"Nama karyawan '{target_name}' tidak ditemukan dalam daftar.")

def user_input_case():
    
    names = []
    n = int(input("Masukkan jumlah nama karyawan: "))
    for i in range(n):
        name = input(f"Masukkan nama karyawan ke-{i+1}: ")
        names.append(name)
    
    
    names.sort()
    print("\nDaftar nama karyawan setelah diurutkan:")
    for name in names:
        print(name)
    
    
    target_name = input("\nMasukkan nama karyawan yang akan dicari: ")
    
    
    result = binary_search(names, target_name)
    
    
    if result != -1:
        print(f"Nama karyawan '{target_name}' ditemukan pada indeks {result}.")
    else:
        print(f"Nama karyawan '{target_name}' tidak ditemukan dalam daftar.")

def main():
    print("Pilih opsi:")
    print("1. Gunakan nama karyawan yang sudah ada")
    print("2. Masukkan data karyawan secara manual")
    choice = int(input("Masukkan pilihan (1/2): "))

    if choice == 1:
        example_case()
    elif choice == 2:
        user_input_case()
    else:
        print("Pilihan tidak valid")


if __name__ == "__main__":
    main()
